#ifndef _LIFT_H_
#define _LIFT_H_

void lift(int speed);
void liftFast(int distance);
void liftSlow(int distance);
void lift_encod(int distance, int speed);
void liftOp(void* parameter);

#endif
