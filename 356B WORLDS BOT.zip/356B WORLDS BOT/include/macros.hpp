void frontDoubleshot();
void frontblueDoubleshot();
void red_midshot();
void backDoubleshot();
void middleDoubleshot();
void one_shot();
void defence_mech();
