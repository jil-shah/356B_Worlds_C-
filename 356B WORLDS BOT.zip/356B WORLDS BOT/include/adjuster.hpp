#ifndef _ADJUSTER_H_
#define _ADJUSTER_H_

void adjust(int vel);

void _adjust(int distance, int vel);

void adjustReset();

void change_angle();

void adjusterOp(void* parameter);

#endif
